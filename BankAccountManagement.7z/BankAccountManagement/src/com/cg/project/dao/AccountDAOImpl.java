package com.cg.project.dao;

import java.util.Map;

import com.cg.project.dto.Customer;

public class AccountDAOImpl implements AccountDAO{
	
	Map<String,Customer> map;
	
	public AccountDAOImpl(){
		map = AccountData.createCollection();
	}
	
	@Override
	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		map.put(customer.getMobileNo(),customer);
		System.out.println("...............New Account Created...............\n\n");
	}

	@Override
	public void deposit(String mobileNo, double amount) {
		// TODO Auto-generated method stub
		Customer customer = map.get(mobileNo);
		double updateAmount = customer.getInitialBalance();
		updateAmount += amount;
		String name = customer.getName();
		String newMobileNo = customer.getMobileNo();
		float age = customer.getAge();
		
		customer.setAge(age);
		customer.setInitialBalance(updateAmount);
		customer.setName(name);
		customer.setMobileNo(newMobileNo);
		
		map.put(newMobileNo, customer);
		System.out.println("...............Amount deposited...............\n\n");
	}

	@Override
	public void withdraw(String mobileNo, double withdrawAmount) {
		// TODO Auto-generated method stub
		Customer customer = map.get(mobileNo);
		double amount = customer.getInitialBalance();
		
		
		
		String name = customer.getName();
		String newMobileNo = customer.getMobileNo();
		float age = customer.getAge();
		
		if(amount - withdrawAmount > 500)
			amount -= withdrawAmount;
		
		customer.setAge(age);
		customer.setInitialBalance(amount);
		customer.setName(name);
		customer.setMobileNo(newMobileNo);
		
		map.put(newMobileNo, customer);
		System.out.println("...............Amount withdrawn...............\n\n");
		
		
	}

	@Override
	public double checkBalance(String mobileNo) {
		// TODO Auto-generated method stub
		Customer custCheckBalance = map.get(mobileNo);
		double amount = custCheckBalance.getInitialBalance();
		return amount;
		
	}

	@Override
	public void fundTransfer(String sender, String reciever, double amount) {
		// TODO Auto-generated method stub
		
		String name, newMobileNo;
		float age;
		@SuppressWarnings("unused")
		double amountFund;
		
		Customer custSender =  map.get(sender);
		Customer custReciever = map.get(reciever);
		
		double recieverAmount = custReciever.getInitialBalance();
		double senderAmount = custSender.getInitialBalance();
		if(!(senderAmount - amount > 1000)){
			System.out.println("..........Insufficient fund, please enter valid amount..........\n\n ");
		}
		else{
			recieverAmount += amount;
			senderAmount -= amount;
			System.out.println("...............Fund Transferred...............\n\n");
			name = custSender.getName();
			newMobileNo = custSender.getMobileNo();
			age = custSender.getAge();
			amountFund = senderAmount;
			
			custSender.setAge(age);
			custSender.setInitialBalance(senderAmount);
			custSender.setMobileNo(newMobileNo);
			custSender.setName(name);
			
			map.put(newMobileNo, custSender);
			
			name = custReciever.getName();
			newMobileNo = custReciever.getMobileNo();
			age = custReciever.getAge();
			amountFund = recieverAmount;
			
			custReciever.setAge(age);
			custReciever.setInitialBalance(recieverAmount);
			custReciever.setMobileNo(newMobileNo);
			custReciever.setName(name);
			
			map.put(newMobileNo, custReciever);
			
		}
		
	}

}
