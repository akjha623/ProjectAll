package com.cg.project.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.project.dto.Customer;

public class AccountData {
	private static Map<String, Customer> customer;
	static Map<String, Customer> createCollection(){
		if(customer == null)
			customer = new HashMap<>();		
		return customer;		
	}

}
