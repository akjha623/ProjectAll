package com.cg.project.exception;

public class NameException extends Exception {


	public NameException() {
		// TODO Auto-generated constructor stub
		super("Invalid Name!!\nFirst letter must be in Caps and rest Small");
	}


	

}
