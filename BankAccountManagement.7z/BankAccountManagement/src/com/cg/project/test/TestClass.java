package com.cg.project.test;

import org.junit.Assert;
import org.junit.Test;

import com.cg.project.exception.NameException;
import com.cg.project.service.AccountService;
import com.cg.project.service.AccountServiceImpl;

public class TestClass {
	@Test(expected=NullPointerException.class)
    public void test_ValidateName_null() throws NameException{
        AccountService service=new AccountServiceImpl();
        service.validateName(null);
    }
    
    @Test
    public void test_validateName_v1() throws NameException{
    
        String name="Akjha123";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateName_v2() throws NameException{
    
        String name="Akshay";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateName_v3() throws NameException{
    
        String name="akshay";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test(expected=NullPointerException.class)
    public void test_ValidateMobNo_null() throws NameException{
        AccountService service=new AccountServiceImpl();
        service.validateMobileNumber(null);
    }
    
    @Test
    public void test_validateMobNo_v1() throws NameException{
    
        String mobNo="AKSJ923871209";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateMobileNumber(mobNo);
        Assert.assertEquals(false,result);
    }
    @Test
    public void test_validateMobNo_v2() throws NameException{
    
        String mobNo="9837971234";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateMobileNumber(mobNo);
        Assert.assertEquals(true,result);
    }
    @Test
    public void test_validateMobNo_v3() throws NameException{
    
        String mobNo="982567";
        AccountService service=new AccountServiceImpl();
        boolean result= service.validateMobileNumber(mobNo);
        Assert.assertEquals(false,result);
    }

}
